
import os
import re
import codecs
from setuptools import setup

setup(name='ndl_tense',
      version='0.0.1',
      description='',
      author='Adnane and Tek',
      packages=['data_preparation', 'data_analysis'])